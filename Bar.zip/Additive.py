class Additive:
    def __init__(self):
        self.calories = 0
        self.name = ""
    
    def editAdditive(self, newCalories, newName):
        self.calories = newCalories
        self.name = newName